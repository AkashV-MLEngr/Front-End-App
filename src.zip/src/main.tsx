import React from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route }
	from "react-router-dom";
import './App';
import PropertiesList from "./components/buyer/PropertiesList";
// import Second from "./components/Second";

function App() {
	return (
		<Router>
			<Routes>
				<Route path="/buyerFlow"
					element={<PropertiesList />} />
				<Route path="/Home"
					element={<App />} />
				
			</Routes>
		</Router>
	);
}

export default App;
